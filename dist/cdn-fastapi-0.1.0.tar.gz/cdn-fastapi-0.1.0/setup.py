# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cdn_fastapi', 'cdn_fastapi.controllers']

package_data = \
{'': ['*'], 'cdn_fastapi': ['public/*']}

install_requires = \
['Pillow>=9.2.0,<10.0.0',
 'fastapi>=0.85.0,<0.86.0',
 'requests>=2.28.1,<3.0.0',
 'uvicorn>=0.18.3,<0.19.0']

setup_kwargs = {
    'name': 'cdn-fastapi',
    'version': '0.1.0',
    'description': '',
    'long_description': '# FASTAPI CDN\n## TANPA LOGIKA',
    'author': 'ari-fatur',
    'author_email': 'ari.arifatur.fatur@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
